from scripts.SolveFeasibility import solve_feasibility
from models.global_vars import global_vars

# path to the grid network RAW file
#casename = 'testcases/IEEE-118_prior_solution.RAW'
#casename = 'code/testcases/GS-4_prior_solution.RAW'
casename = 'code/testcases/GS-4_stressed.RAW'
#casename = '/Users/oscardring/Desktop/Oscar Dring/UVM /UVM school work Senior/School Work/Power/Project 3/295B_uvm_2023-project3/code/testcases/IEEE_14_prior_solution.m'
#casename = 'code/testcases/IEEE-14_stressed_1.RAW'
#casename = 'code/testcases/IEEE-14_stressed2_fixed.RAW'
# the settings for the solver
settings = {
    "Tolerance": 1E-04, ## changing tol to make it converge 
    "Max Iters": 1000,
    "Limiting":  False
}

# run the solver
solve_feasibility(casename, settings)