from __future__ import division
from models.Buses import Buses
import numpy as np



class Slack:

    def __init__(self,
                 Bus,
                 Vset,
                 ang,
                 Pinit,
                 Qinit):
        """Initialize slack bus in the power grid.

        Args:
            Bus (int): the bus number corresponding to the slack bus.
            Vset (float): the voltage setpoint that the slack bus must remain fixed at.
            ang (float): the slack bus voltage angle that it remains fixed at.
            Pinit (float): the initial active power that the slack bus is supplying
            Qinit (float): the initial reactive power that the slack bus is supplying
        """
        # You will need to implement the remainder of the __init__ function yourself.
        self.Bus = Bus
        self.Vset = Vset
        self.ang = ang
        self.Pinit = Pinit
        self.Qinit = Qinit

        #Get Vr and Vi from Vset and ang
        self.Vr = Vset*np.cos(ang*np.pi/180)
        self.Vi = Vset*np.sin(ang*np.pi/180)

    def stampY(self,val,i,j,Y):
        Y[i,j] += val
        pass

    def stampJ(self,val,i,J):
        J[i] += val
        pass

    def assign_nodes(self,bus):
        self.node_Vr_Slack = Buses._node_index.__next__()
        self.node_Vi_Slack = Buses._node_index.__next__()

        self.vr = bus[Buses.all_bus_key_[self.Bus]].node_Vr
        self.vi = bus[Buses.all_bus_key_[self.Bus]].node_Vi

    # You should also add some other class functions you deem necessary for stamping,
    # initializing, and processing results.
    def stamp(self,Ylinear,Jlinear,bus):
        #stamp real
        # print(Ylinear)
        self.stampY(1,self.vr,self.node_Vr_Slack,Ylinear)
        self.stampY(1,self.node_Vr_Slack,self.vr,Ylinear)
        self.stampJ(self.Vr,self.node_Vr_Slack,Jlinear)
        # print('THIS IS Y LINEAR ')

        #stamp imaginary
        self.stampY(1,self.vi,self.node_Vi_Slack,Ylinear)
        self.stampY(1,self.node_Vi_Slack,self.vi,Ylinear)
        self.stampJ(self.Vi,self.node_Vi_Slack,Jlinear)
        # print(Ylinear)
        