from __future__ import division
from itertools import count
from models.Buses import Buses


class Shunts:
    _ids = count(0)

    def __init__(self,
                 Bus,
                 G_MW,
                 B_MVAR,
                 shunt_type,
                 Vhi,
                 Vlo,
                 Bmax,
                 Bmin,
                 Binit,
                 controlBus,
                 flag_control_shunt_bus=False,
                 Nsteps=[0],
                 Bstep=[0]):

        """ Initialize a shunt in the power grid.
        Args:
            Bus (int): the bus where the shunt is located
            G_MW (float): the active component of the shunt admittance as MW per unit voltage
            B_MVAR (float): reactive component of the shunt admittance as  MVar per unit voltage
            shunt_type (int): the shunt control mode, if switched shunt
            Vhi (float): if switched shunt, the upper voltage limit
            Vlo (float): if switched shunt, the lower voltage limit
            Bmax (float): the maximum shunt susceptance possible if it is a switched shunt
            Bmin (float): the minimum shunt susceptance possible if it is a switched shunt
            Binit (float): the initial switched shunt susceptance
            controlBus (int): the bus that the shunt controls if applicable
            flag_control_shunt_bus (bool): flag that indicates if the shunt should be controlling another bus
            Nsteps (list): the number of steps by which the switched shunt should adjust itself
            Bstep (list): the admittance increase for each step in Nstep as MVar at unity voltage
        """
        #self.id = self._ids.__next__()
                #this line is just a counter, gives a uqie id 
        self.id = Shunts._ids.__next__()
        self.Bus = Bus
        self.G_MW = G_MW
        self.B_MVAR = B_MVAR
        self.Binit = Binit


        # You will need to implement the remainder of the __init__ function yourself.
        # You should also add some other class functions you deem necessary for stamping,
        # initializing, and processing results.

    def stampY(self,i,j,val,Y):
        Y[i,j] += val
        pass

    def stampJ(self,i,val,J):
        J[i] += val
        pass

    #need to stamp shunts here
    def assign_nodes(self,bus):
        self.Vi_node = bus[Buses.all_bus_key_[self.Bus]].node_Vi
        self.Vr_node = bus[Buses.all_bus_key_[self.Bus]].node_Vr

    def stamp (self,Ylinear):
        G = self.G_MW
        B = self.B_MVAR

        #stamping the real
        self.stampY(G, self.Vr_node,self.Vr_node,Ylinear)
        self.stampY(-B,self.Vr_node, self.Vi_node,Ylinear)

        ##stamping the imag
        self.stampY(G,self.Vi_node,self.Vi_node,Ylinear)
        self.stampY(B,self.Vi_node,self.Vr_node,Ylinear)

        pass
