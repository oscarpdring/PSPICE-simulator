from __future__ import division
from itertools import count
from models.Buses import Buses



class Loads:
    _ids = count(0)

    def __init__(self,
                 Bus,
                 P,
                 Q,
                 IP,
                 IQ,
                 ZP,
                 ZQ,
                 area,
                 status):
        """Initialize an instance of a PQ or ZIP load in the power grid.

        Args:
            Bus (int): the bus where the load is located
            P (float): the active power of a constant power (PQ) load.
            Q (float): the reactive power of a constant power (PQ) load.
            IP (float): the active power component of a constant current load.
            IQ (float): the reactive power component of a constant current load.
            ZP (float): the active power component of a constant admittance load.
            ZQ (float): the reactive power component of a constant admittance load.
            area (int): location where the load is assigned to.
            status (bool): indicates if the load is in-service or out-of-service.
        """
        #this line is just a counter, gives a uqie id 
        self.id = Loads._ids.__next__()
        self.Bus = Bus

        #divide by 100 to normalize it 
        self.P = P/100
        self.Q = Q/100
        

        # You will need to implement the remainder of the __init__ function yourself.
        # You should also add some other class functions you deem necessary for stamping,
        # initializing, and processing results.
    def stampY(self,val,i,j,Y):
        Y[i,j] += val
        pass

    def stampJ(self,val,i,J):
        J[i] += val
        pass

    def stamp(self, Ynonlinear, Jnonlinear, bus, v_init):
        
        self.vr = bus[Buses.all_bus_key_[self.Bus]].node_Vr
        self.vi = bus[Buses.all_bus_key_[self.Bus]].node_Vi
        
        vr = v_init[self.vr]
        vi = v_init[self.vi]
        Q = self.Q
        P = self.P
        ir = (P*vr+Q*vi)/(vr**2+vi**2)
        ii = (P*vi-Q*vr)/(vr**2+vi**2)

        # Real Part 
        dIrdVr = (P*(vi**2-vr**2)-2*Q*vr*vi)/((vr**2+vi**2)**2)     #Conductance at index vr
        dIrdVi = (Q*(vr**2-vi**2)-2*P*vr*vi)/((vr**2+vi**2)**2)    #Dependent source, at index vi
        Ir_hist = ir-dIrdVr*vr-dIrdVi*vi       #Independent source history

        self.stampY(dIrdVr,self.vr,self.vr,Ynonlinear)
        self.stampY(dIrdVi,self.vr,self.vi,Ynonlinear)
        self.stampJ(-Ir_hist,self.vr,Jnonlinear)    #stamp independent current source

        # Imaginary Part 
        dIidVi = -dIrdVr
        dIidVr = dIrdVi
        Ii_hist = ii-dIidVi*vi-dIidVr*vr

        self.stampY(dIidVi,self.vi,self.vi,Ynonlinear)
        self.stampY(dIidVr,self.vi,self.vr,Ynonlinear)
        self.stampJ(-Ii_hist,self.vi,Jnonlinear)