from __future__ import division
from itertools import count
from models.Buses import Buses


class Branches:
    _ids = count(0)

    def __init__(self,
                 from_bus,
                 to_bus,
                 r,
                 x,
                 b,
                 status,
                 rateA,
                 rateB,
                 rateC):
        """Initialize a branch in the power grid.

        Args:
            from_bus (int): the bus number at the sending end of the branch.
            to_bus (int): the bus number at the receiving end of the branch.
            r (float): the branch resistance
            x (float): the branch reactance
            b (float): the branch susceptance
            status (bool): indicates if the branch is online or offline
            rateA (float): The 1st rating of the line.
            rateB (float): The 2nd rating of the line
            rateC (float): The 3rd rating of the line.
        """
        self.id = self._ids.__next__()
        self.r = r
        self.x = x
        self.b = b
        self.from_bus = from_bus
        self.to_bus = to_bus

    def stampY(self,val,i,j,Y):
        Y[i,j] += val

    def stampJ(self,i,val,J):
        J[i] += val

    # You will need to implement the remainder of the __init__ function yourself.
    # You should also add some other class functions you deem necessary for stamping,
    # initializing, and processing results.

    def stamp(self,Ylinear,Jlinear, bus):
        Gr = self.r/(self.r**2+self.x**2)
        Gi = self.r/(self.r**2+self.x**2)

        #therefor Gi = Gr
       
        self.from_i = bus[Buses.all_bus_key_[self.from_bus]].node_Vi
        self.to_i = bus[Buses.all_bus_key_[self.to_bus]].node_Vi
        
        self.from_r = bus[Buses.all_bus_key_[self.from_bus]].node_Vr
        self.to_r = bus[Buses.all_bus_key_[self.to_bus]].node_Vr


        #conductance
        self.stampY(Gr,self.to_r,self.to_r, Ylinear)
        self.stampY(-Gr,self.to_r,self.from_r,Ylinear)
        self.stampY(Gr,self.from_r,self.from_r, Ylinear)
        self.stampY(-Gr, self.from_r, self.to_r,Ylinear)

        self.stampY(Gi,self.to_i,self.to_i, Ylinear)
        self.stampY(-Gi,self.to_i,self.from_i,Ylinear)
        self.stampY(Gi,self.from_i,self.from_i, Ylinear)
        self.stampY(-Gi, self.from_i, self.to_i,Ylinear)


        #voltage controlled current source
        VCCSr = self.x/(self.r**2 + self.x**2)
        VCCSi = -self.x/(self.r**2 + self.x**2)

        self.stampY(VCCSr,self.to_r,self.to_i, Ylinear)
        self.stampY(-VCCSr,self.to_r,self.from_i,Ylinear)
        self.stampY(VCCSr,self.from_r,self.from_i, Ylinear)
        self.stampY(-VCCSr, self.from_r, self.to_i,Ylinear)

        self.stampY(VCCSi,self.to_i,self.to_r, Ylinear)
        self.stampY(-VCCSi,self.to_i,self.from_r,Ylinear)
        self.stampY(VCCSi,self.from_i,self.from_r, Ylinear)
        self.stampY(-VCCSi, self.from_i, self.to_r,Ylinear)

        #shunt

        Btranline_r = -self.b/2 #im not sure this is the right sign 
        Btranline_i = self.b/2

        self.stampY(Btranline_r,self.to_r,self.to_i, Ylinear)
        self.stampY(Btranline_r,self.from_r,self.from_i, Ylinear)
    
        self.stampY(Btranline_i,self.to_i,self.to_r, Ylinear)
        self.stampY(Btranline_i,self.from_i,self.from_r, Ylinear)
        

