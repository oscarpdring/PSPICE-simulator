from __future__ import division
from itertools import count
from models.Buses import Buses
import numpy as np


class Transformers:
    _ids = count(0)

    def __init__(self,
                 from_bus,
                 to_bus,
                 r,
                 x,
                 status,
                 tr,
                 ang,
                 Gsh_raw,
                 Bsh_raw,
                 rating):
        """Initialize a transformer instance

        Args:
            from_bus (int): the primary or sending end bus of the transformer.
            to_bus (int): the secondary or receiving end bus of the transformer
            r (float): the line resitance of the transformer in
            x (float): the line reactance of the transformer
            status (int): indicates if the transformer is active or not
            tr (float): transformer turns ratio
            ang (float): the phase shift angle of the transformer
            Gsh_raw (float): the shunt conductance of the transformer
            Bsh_raw (float): the shunt admittance of the transformer
            rating (float): the rating in MVA of the transformer
        """
        self.id = self._ids.__next__()
        self.from_bus = from_bus
        self.to_bus = to_bus
        self.r = r
        self.x = x
        self.tr = tr
        self.ang = ang
        self.Gsh_raw = Gsh_raw
        self.Bsh_raw = Bsh_raw
        self.rating = rating
        self.status = status

        # You will need to implement the remainder of the __init__ function yourself.
        # You should also add some other class functions you deem necessary for stamping,
        # initializing, and processing results.

    def stampY(self,val,i,j,Y):
        Y[i,j] += val
        pass


    def stampJ(self,i,val,J):
        J[i] += val
        pass
    
    def assign_nodes(self,bus):
         #this is how you make new nodes
        #primary
        self.node_r_prim = Buses._node_index.__next__()
        self.node_i_prim = Buses._node_index.__next__()

        #secondary
        self.node_r_sec = Buses._node_index.__next__()
        self.node_i_sec = Buses._node_index.__next__()

        #New nodes voltage supplies
        self.r_volt_cos = Buses._node_index.__next__()
        self.i_volt_cos = Buses._node_index.__next__()
        self.r_volt_sin = Buses._node_index.__next__()
        self.i_volt_sin = Buses._node_index.__next__()
        
        self.from_i = bus[Buses.all_bus_key_[self.from_bus]].node_Vi
        self.to_i = bus[Buses.all_bus_key_[self.to_bus]].node_Vi
        self.from_r = bus[Buses.all_bus_key_[self.from_bus]].node_Vr
        self.to_r = bus[Buses.all_bus_key_[self.to_bus]].node_Vr

    #need to stamp transformers here
    def stamp (self, Ylinear, Jlinear):
        from_r = self.from_r
        from_i = self.from_i
        to_r = self.to_r
        to_i = self.to_i
        tr = self.tr
        ang = self.ang
        
        P_shift = np.cos(ang*np.pi/180)
        P_shift2 = np.sin(ang*np.pi/180)

        A_cos = tr*P_shift
        A_sin = tr*P_shift2

        Gr = self.r/(self.r**2+self.x**2)
        Gi = self.r/(self.r**2+self.x**2)
    

        #conductance
        self.stampY(Gr,self.to_r,self.to_r, Ylinear)
        self.stampY(-Gr,self.to_r,self.from_r,Ylinear)
        self.stampY(Gr,self.from_r,self.from_r, Ylinear)
        self.stampY(-Gr, self.from_r, self.to_r,Ylinear)

        self.stampY(Gi,self.to_i,self.to_i, Ylinear)
        self.stampY(-Gi,self.to_i,self.from_i,Ylinear)
        self.stampY(Gi,self.from_i,self.from_i, Ylinear)
        self.stampY(-Gi, self.from_i, self.to_i,Ylinear)
        

        #VCVS real 
        self.stampY(1, from_r, self.r_volt_cos, Ylinear)
        self.stampY(-1, self.node_r_prim, self.r_volt_cos ,Ylinear)

        self.stampY(1, self.r_volt_cos, from_r, Ylinear)
        self.stampY(-1, self.r_volt_cos, self.node_r_prim, Ylinear)
        self.stampY(-A_cos, self.r_volt_cos, self.node_r_sec, Ylinear)

        self.stampY(1, self.node_r_prim, self.r_volt_sin, Ylinear)
        self.stampY(1, self.r_volt_sin, self.node_r_prim, Ylinear)

        self.stampY(A_sin, self.r_volt_sin, self.node_i_sec, Ylinear)


        #VCVS imaginary 
        self.stampY(1, from_i, self.i_volt_cos, Ylinear)
        self.stampY(-1, self.node_i_prim, self.i_volt_cos ,Ylinear)

        self.stampY(1, self.i_volt_cos, from_i, Ylinear)
        self.stampY(-1, self.i_volt_cos, self.node_r_prim, Ylinear)
        self.stampY(-A_cos, self.i_volt_cos, self.node_r_sec, Ylinear)

        self.stampY(1, self.node_i_prim, self.i_volt_sin, Ylinear)
        self.stampY(1, self.i_volt_sin, self.node_i_prim, Ylinear)

        self.stampY(A_sin, self.i_volt_sin, self.node_r_sec, Ylinear)

        ##
        primary_iR_index = self.r_volt_cos #index for the primary real current of the VCVS
        primary_iI_index = self.i_volt_cos #index for the primary imaxlossnary current of the VCVS


        #real stamps for CCCS
        self.stampY(-A_cos, self.node_r_sec, primary_iR_index, Ylinear)
        self.stampY(-A_sin, self.node_r_sec, primary_iI_index, Ylinear)

        #imaxlossnary stamps for CCCS
        self.stampY(A_sin, self.node_i_sec, primary_iR_index, Ylinear)
        self.stampY(-A_cos, self.node_i_sec, primary_iI_index, Ylinear)

    