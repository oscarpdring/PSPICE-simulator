from __future__ import division
from itertools import count
from scripts.global_vars import global_vars
from models.Buses import Buses


class Generators:
    _ids = count(0)
    RemoteBusGens = dict()
    RemoteBusRMPCT = dict()
    gen_bus_key_ = {}
    total_P = 0

    def __init__(self,
                 Bus,
                 P,
                 Vset,
                 Qmax,
                 Qmin,
                 Pmax,
                 Pmin,
                 Qinit,
                 RemoteBus,
                 RMPCT,
                 gen_type):
        #Bus = 1 #look at loads note

        """Initialize an instance of a generator in the power grid.
        PV!!!!
        Args:
            
            Bus (int): the bus number where the generator is located. CHECK
            P (float): the current amount of active power the generator is providing.
            Vset (float): the voltage setpoint that the generator must remain fixed at.
            Qmax (float): maximum reactive power
            Qmin (float): minimum reactive power
            Pmax (float): maximum active power
            Pmin (float): minimum active power
            Qinit (float): the initial amount of reactive power that the generator is supplying or absorbing.
            RemoteBus (int): the remote bus that the generator is controlling
            RMPCT (float): the percent of total MVAR required to hand the voltage at the controlled bus
            gen_type (str): the type of generator
        """
        self.Qmin =  Qmax
        self.Qmax = Qmin
        self.Bus = Bus
        self.id = self._ids.__next__()
        self.Vset = Vset

        #normalize 
        self.P = P/100


    def stampY(self,i,j,val,Y):
        Y[i,j] += val
        pass

    def stampJ(self,i,val,J):
        J[i] += val
        pass

        # You will need to implement the remainder of the __init__ function yourself.
        # You should also add some other class functions you deem necessary for stamping,
        # initializing, and processing results.

    
    
    
    def stamp(self, Ynonlinear, Jnonlinear, bus, v):

      
        self.Vr_node = bus[Buses.all_bus_key_[self.Bus]].node_Vr
        self.Vi_node = bus[Buses.all_bus_key_[self.Bus]].node_Vi
       
        self.Q_node = bus[Buses.all_bus_key_[self.Bus]].node_Q

        Q = v[self.Q_node] 

        P = -self.P
        vr = v[self.Vr_node]
        vi = v[self.Vi_node]


        Irg_hist = (P*vr - Q*vi)/(vr**2 + vi**2)
        Iig_hist = (P*vi + Q*vr)/(vr**2 + vi**2)

        #partials

        dIrdVr = (P*(vi**2-vr**2)+2*Q*vr*vi)/((vr**2 + vi**2)**2)
        dIrdVi = (Q*(vi**2-vr**2)-2*P*vr*vi)/((vr**2 + vi**2)**2)
        dIrdQ = (-vi)/((vr**2 + vi**2))
        Vr_J_stamp = Irg_hist - dIrdQ*Q - dIrdVr*vr - dIrdVi*vi 

        #real
        self.stampY(self.Vr_node, self.Vr_node, dIrdVr, Ynonlinear)
        self.stampY(self.Vr_node, self.Vi_node, dIrdVi, Ynonlinear)
        self.stampY(self.Vr_node, self.Q_node, dIrdQ, Ynonlinear)
        self.stampJ(self.Vr_node, -Vr_J_stamp, Jnonlinear)


        #imaginary
        dIidVr = dIrdVi 
        dIidVi = -dIrdVr
        dIidQ = (vr)/((vr**2 + vi**2))

        Vi_J_stamp = Iig_hist - dIidQ*Q - dIidVr* vr - dIidVi*vi 

        self.stampY(self.Vi_node, self.Vr_node, dIidVr, Ynonlinear)
        self.stampY(self.Vi_node, self.Vi_node, dIidVi, Ynonlinear)
        self.stampY(self.Vi_node, self.Q_node, dIidQ, Ynonlinear)
        self.stampJ(self.Vi_node, -Vi_J_stamp, Jnonlinear)

        vset_hist = self.Vset**2 - vr**2 - vi**2
        dvsetdvr = -2*vr
        dvsetdvi = -2*vi #check these two 
        Vset_J_stamp = -vset_hist + dvsetdvr*vr + dvsetdvi*vi

        self.stampY(self.Q_node, self.Vr_node, dvsetdvr, Ynonlinear)
        self.stampY(self.Q_node, self.Vi_node, dvsetdvi, Ynonlinear)
        self.stampJ(self.Q_node, Vset_J_stamp, Jnonlinear)
        
        return Q
    







        