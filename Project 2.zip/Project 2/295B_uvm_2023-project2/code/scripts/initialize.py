
def initialize(Vinit, bus, slack):
    #go thru all the busses

    for ele in bus: 
        if ele.Type == 1 or ele.Type == 3:
            Vinit[ele.node_Vr] = 1
            Vinit[ele.node_Vi] = 0

        elif ele.Type == 2:
            Vinit[ele.node_Q] = 0.01
            Vinit[ele.node_Vr] = 1
            Vinit[ele.node_Vi] = 0

    for ele in slack: 
            Vinit[ele.node_Vi_Slack] = 1e-4
            Vinit[ele.node_Vr_Slack] = 1e-4

    pass